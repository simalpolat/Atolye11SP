# HangmanGame
An interactive HangMan Game made using 'C# in Windows Forms Application

You can play the game by going into the HangMan folder then bin then Debug and then clicking on HangMan Game. Have fun playing :)
